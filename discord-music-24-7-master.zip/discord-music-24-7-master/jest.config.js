module.exports = {
  testEnvironment: 'node',
  setupFiles: ['./test/setupEnv.js']
};