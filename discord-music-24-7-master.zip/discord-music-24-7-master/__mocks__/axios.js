module.exports = {
  default: {
    get: jest.fn()
  }
};
