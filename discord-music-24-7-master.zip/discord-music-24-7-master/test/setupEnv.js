/* eslint-disable prefer-destructuring */
/* eslint-disable no-global-assign */
TextDecoder = require('text-encoding').TextDecoder;
